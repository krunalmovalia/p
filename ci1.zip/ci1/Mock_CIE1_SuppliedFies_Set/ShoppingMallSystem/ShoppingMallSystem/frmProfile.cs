﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoppingMallSystem
{
    public partial class frmProfile : Form
    {
        public frmProfile()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn_Click(object sender, EventArgs e)
        {
            String name, Org, comment;
            name = name1.Text;
            Org = organization.Text;
            comment = cmt.Text;
            MessageBox.Show("Message of " + name + " from " + Org + " with " + comment);
        }
    }
}
