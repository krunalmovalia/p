﻿using System;
using System.Windows.Forms;

namespace ShoppingMallSystem
{
    public partial class frmCalculator : Form
    {
        public frmCalculator()
        {
            InitializeComponent();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
            double n1, n2, res;
            n1 = double.Parse(number1.Text);
            n2 = double.Parse(number2.Text);
            res = n1 + n2;
            result.Text = res.ToString();  
        }

        private void N1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Result_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
