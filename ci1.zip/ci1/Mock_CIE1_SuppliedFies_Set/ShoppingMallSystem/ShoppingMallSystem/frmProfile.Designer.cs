﻿namespace ShoppingMallSystem
{
    partial class frmProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn = new System.Windows.Forms.Button();
            this.name1 = new System.Windows.Forms.TextBox();
            this.organization = new System.Windows.Forms.TextBox();
            this.cmt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(135, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "organization";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(135, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "comment";
            // 
            // btn
            // 
            this.btn.Location = new System.Drawing.Point(256, 286);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(75, 23);
            this.btn.TabIndex = 1;
            this.btn.Text = "Send Message";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.Btn_Click);
            // 
            // name1
            // 
            this.name1.Location = new System.Drawing.Point(378, 91);
            this.name1.Name = "name1";
            this.name1.Size = new System.Drawing.Size(100, 22);
            this.name1.TabIndex = 2;
            this.name1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // organization
            // 
            this.organization.Location = new System.Drawing.Point(378, 139);
            this.organization.Name = "organization";
            this.organization.Size = new System.Drawing.Size(100, 22);
            this.organization.TabIndex = 2;
            // 
            // cmt
            // 
            this.cmt.Location = new System.Drawing.Point(378, 192);
            this.cmt.Name = "cmt";
            this.cmt.Size = new System.Drawing.Size(100, 22);
            this.cmt.TabIndex = 2;
            // 
            // frmProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 446);
            this.Controls.Add(this.cmt);
            this.Controls.Add(this.organization);
            this.Controls.Add(this.name1);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmProfile";
            this.Text = "frmProfile";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.TextBox name1;
        private System.Windows.Forms.TextBox organization;
        private System.Windows.Forms.TextBox cmt;
    }
}