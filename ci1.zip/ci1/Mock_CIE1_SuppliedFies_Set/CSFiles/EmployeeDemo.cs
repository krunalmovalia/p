using System;

namespace MockTest
{
    class Employee
    {
        public static int ID;
        public static string Name, Email, Country;
        public  void SetData(int id, string name, string email, string country)
        {
            ID = id;
            Name = name;
            Email = email;
            Country = country;
        }
        public void Display()
        {
            Console.WriteLine("ID : " + ID);
            Console.WriteLine("Name : " + Name);
            Console.WriteLine("Email : " + Email);
            Console.WriteLine("Country : " + Country);

        }
    }
    class EmployeeDemo
    {
        public static void Main(String[] args)
        {
            int id;
            String name, email, country;
            Employee e = new Employee();
            Console.WriteLine("Enter ID : ");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name : ");
            name = Console.ReadLine();
            Console.WriteLine("Enter Email : ");
            email = Console.ReadLine();
            Console.WriteLine("Enter Country : ");
            country = Console.ReadLine();
            e.SetData(id,name,email,country);
            e.Display();
			Console.Read();
        }

    }
}
