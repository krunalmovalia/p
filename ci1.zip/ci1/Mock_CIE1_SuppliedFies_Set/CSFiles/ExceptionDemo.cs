using System;
class MyClient
{
      public static void Main()
      {
            int x = 0;
            
            try
            {
                  int div = 100/x;
            Console.WriteLine(div);
            
            
            }
            catch (System.Exception e)
            {
                  
            Console.WriteLine(e);


                  
            }finally{
                  Console.WriteLine("program executed This is finally");

            }
            Console.Read();
            
       }
} 
