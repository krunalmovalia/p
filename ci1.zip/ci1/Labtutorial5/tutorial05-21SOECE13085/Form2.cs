﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labtutorial5
{


    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        String a,b,c;

        private void button1_Click(object sender, EventArgs e)
        {
            a = textBox1.Text;
            b = textBox2.Text;
            c = textBox3.Text;

            MessageBox.Show("Message of "+ a +" from "+ b +" with "+ c );
        }
    }
}
