﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labtutorial5
{
    public partial class Form4 : Form
    {

        int a, b, c;

        

        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox2.Text);

            //    if(!radioButton1.Checked || !radioButton2.Checked || !radioButton3.Checked || !radioButton4.Checked)
            //  {
            //    MessageBox.Show("Select any Operation ");
            //}

           
        //    if (textBox1.Text == "" && textBox2.Text == "")
          //  {

            //    MessageBox.Show("enter  the numbers correctly ");
            //}
            //else
           // { }

                if (radioButton1.Checked)
                {
                    c = a + b;

                    label3.Text = (a + " and " + b + " Addition is " + c);
                    radioButton1.Checked = false;
                }
                else if (radioButton2.Checked)
                {
                    c = a - b;

                    label3.Text = (a + " and " + b + " Substraction is " + c);
                    radioButton2.Checked = false;

                }

                else if (radioButton3.Checked)
                {
                    c = a * b;

                    label3.Text = (a + " and " + b + " Multiplication is " + c);
                    radioButton3.Checked = false;

                }
                else
                {
                    c = a / b;

                    label3.Text = (a + " and " + b + " Division is " + c);
                    radioButton4.Checked = false;

                }
            
        }
    }
}
